import os
from os import system
tid = 0
while True:
    os.system("node dist/index")
    tid += 1
    print(str(tid))

    
